function defineSoundType(soundType) {
    var option = document.getElementById(soundType);
    option.setAttribute("selected", "");
}